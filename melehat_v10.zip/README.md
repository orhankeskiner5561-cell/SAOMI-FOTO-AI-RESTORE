# MELEHAT TELSİZ — Android v0.10

Bu sürümde 6 haneli e-posta OTP ekranı kaldırıldı.

Yeni giriş akışı:
1. Telefon numarası + e-posta girilir.
2. Supabase varsayılan e-posta sistemi güvenli giriş bağlantısı yollar.
3. Kullanıcı maildeki bağlantıya aynı telefondan dokunur.
4. `melehat://auth-callback` ile uygulama açılır ve oturum alınır.
5. İlk girişte ad-soyad + profil fotoğrafı tamamlanır.
6. Telefon değişirse aynı e-posta ile yeniden bağlantı istenir.
7. Buluttaki kayıtlı telefon numarası farklıysa giriş reddedilir.

## Supabase'te bir kez yapılması gereken ücretsiz ayar
Authentication > URL Configuration > Redirect URLs içine şunu ekleyin:

`melehat://auth-callback`

Özel SMTP, Twilio veya ücretli SMS sağlayıcısı gerekmez.
