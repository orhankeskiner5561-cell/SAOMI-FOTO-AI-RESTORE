create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  phone text not null,
  full_name text not null,
  photo_url text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.channels (
  id text primary key,
  name text not null,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.channel_members (
  channel_id text not null,
  channel_name text not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (channel_id, user_id)
);

create table if not exists public.channel_floor (
  channel_id text primary key,
  speaker_user_id uuid references auth.users(id) on delete set null,
  acquired_at timestamptz,
  lease_until timestamptz
);

alter table public.profiles enable row level security;
alter table public.channels enable row level security;
alter table public.channel_members enable row level security;
alter table public.channel_floor enable row level security;

create policy "profiles_read_authenticated"
on public.profiles for select
to authenticated
using (true);

create policy "profiles_own_write"
on public.profiles for all
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "channels_read_authenticated"
on public.channels for select
to authenticated
using (true);

create policy "channels_create_authenticated"
on public.channels for insert
to authenticated
with check (created_by = auth.uid());

create policy "members_read_authenticated"
on public.channel_members for select
to authenticated
using (true);

create policy "members_own_write"
on public.channel_members for insert
to authenticated
with check (user_id = auth.uid());

create policy "members_own_delete"
on public.channel_members for delete
to authenticated
using (user_id = auth.uid());

create policy "floor_read_authenticated"
on public.channel_floor for select
to authenticated
using (true);

create or replace function public.acquire_channel_floor(p_channel_id text, p_lease_seconds integer default 15)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := now();
  v_until timestamptz := now() + make_interval(secs => greatest(3, least(p_lease_seconds, 60)));
begin
  insert into public.channel_floor(channel_id, speaker_user_id, acquired_at, lease_until)
  values (p_channel_id, auth.uid(), v_now, v_until)
  on conflict (channel_id) do update
  set speaker_user_id = excluded.speaker_user_id,
      acquired_at = excluded.acquired_at,
      lease_until = excluded.lease_until
  where public.channel_floor.speaker_user_id = auth.uid()
     or public.channel_floor.lease_until is null
     or public.channel_floor.lease_until < v_now;

  return exists (
    select 1 from public.channel_floor
    where channel_id = p_channel_id
      and speaker_user_id = auth.uid()
      and lease_until >= v_now
  );
end;
$$;

create or replace function public.release_channel_floor(p_channel_id text)
returns void
language sql
security definer
set search_path = public
as $$
  update public.channel_floor
  set speaker_user_id = null,
      acquired_at = null,
      lease_until = null
  where channel_id = p_channel_id
    and speaker_user_id = auth.uid();
$$;

grant execute on function public.acquire_channel_floor(text, integer) to authenticated;
grant execute on function public.release_channel_floor(text) to authenticated;
