package com.saomi.telsiz.voice

import android.content.Context
import com.saomi.telsiz.BuildConfig
import com.saomi.telsiz.data.SessionStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

data class LiveKitCredentials(
    val serverUrl: String,
    val participantToken: String
)

class TokenClient(private val context: Context) {
    private val http = OkHttpClient()
    private val json = "application/json; charset=utf-8".toMediaType()

    suspend fun fetch(
        roomName: String,
        participantName: String,
        participantIdentity: String
    ): LiveKitCredentials? = withContext(Dispatchers.IO) {
        val endpoint = BuildConfig.TOKEN_ENDPOINT
        val session = SessionStore(context).load()
        if (endpoint.isBlank() || session == null) return@withContext null

        val body = JSONObject()
            .put("roomName", roomName)
            .put("participantName", participantName)
            .put("participantIdentity", participantIdentity)
            .toString()
            .toRequestBody(json)

        val request = Request.Builder()
            .url(endpoint)
            .addHeader("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            .addHeader("Authorization", "Bearer ${session.accessToken}")
            .post(body)
            .build()

        runCatching {
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use null
                val raw = response.body?.string().orEmpty()
                val o = JSONObject(raw)
                val server = o.optString("serverUrl").ifBlank { o.optString("server_url") }
                val token = o.optString("participantToken").ifBlank { o.optString("participant_token") }
                if (server.isBlank() || token.isBlank()) null
                else LiveKitCredentials(server, token)
            }
        }.getOrNull()
    }
}
