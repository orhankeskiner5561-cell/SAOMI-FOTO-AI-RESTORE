package com.saomi.telsiz.service

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.PowerManager
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.saomi.telsiz.audio.AudioRouteManager
import com.saomi.telsiz.audio.MediaPttController
import com.saomi.telsiz.net.NetworkMonitor
import com.saomi.telsiz.data.BackendApi
import com.saomi.telsiz.data.LocalStore
import com.saomi.telsiz.data.SessionStore
import com.saomi.telsiz.voice.LiveKitPttClient
import kotlinx.coroutines.*

class PttForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var ptt: LiveKitPttClient
    private lateinit var store: LocalStore
    private lateinit var sessions: SessionStore
    private lateinit var backend: BackendApi
    private lateinit var audioRoute: AudioRouteManager
    private lateinit var mediaPtt: MediaPttController
    private lateinit var networkMonitor: NetworkMonitor
    private var wakeLock: PowerManager.WakeLock? = null

    private var started = false
    private var transmitting = false
    private var leaseJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        ptt = LiveKitPttClient(applicationContext)
        store = LocalStore(applicationContext)
        sessions = SessionStore(applicationContext)
        backend = BackendApi(applicationContext)
        audioRoute = AudioRouteManager(applicationContext)
        mediaPtt = MediaPttController(applicationContext) {
            val i = Intent(applicationContext, PttForegroundService::class.java).apply {
                action = ACTION_TOGGLE_PTT
            }
            startService(i)
        }
        networkMonitor = NetworkMonitor(
            applicationContext,
            onAvailable = {
                if (started) {
                    scope.launch {
                        val ok = ptt.connect(store.loadProfile(), store.loadActiveChannel())
                        updateNotification(
                            if (ok) "Bağlantı geri geldi • Bas-konuş hazır"
                            else "İnternet var • Ses sunucusu bekleniyor"
                        )
                    }
                }
            },
            onLost = {
                if (started) updateNotification("İNTERNET YOK • Yeniden bağlanacak")
            }
        )
        networkMonitor.start()
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "saomi:telsiz"
        ).apply { setReferenceCounted(false) }
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startAsForeground("Bağlanıyor…")
                started = true
                store.setRadioEnabled(true)
                if (wakeLock?.isHeld != true) wakeLock?.acquire()
                val route = audioRoute.activateBestRoute()
                updateNotification("Ses çıkışı: $route • Bağlanıyor…")
                scope.launch {
                    val ok = ptt.connect(store.loadProfile(), store.loadActiveChannel())
                    updateNotification(
                        if (ok) "Kanal dinlemede • Bas-konuş hazır"
                        else "Ses sunucusu bağlantısı bekleniyor"
                    )
                }
            }

            ACTION_STOP -> {
                scope.launch { stopRadio() }
            }

            ACTION_PTT_DOWN -> {
                if (started && !transmitting) scope.launch { beginTransmit() }
            }

            ACTION_PTT_UP -> {
                if (started && transmitting) scope.launch { endTransmit() }
            }

            ACTION_TOGGLE_PTT -> {
                if (started) {
                    if (transmitting) scope.launch { endTransmit() }
                    else scope.launch { beginTransmit() }
                }
            }
        }
        return START_STICKY
    }

    private suspend fun beginTransmit() {
        val session = sessions.load()
        val channel = store.loadActiveChannel()

        if (session == null) {
            updateNotification("Telefon doğrulaması gerekli")
            return
        }

        updateNotification("Kanal kontrol ediliyor…")
        val floor = backend.acquireFloor(session, channel.id, 15)
        if (!floor) {
            updateNotification("KANAL MEŞGUL • Başka biri konuşuyor")
            return
        }

        val enabled = ptt.setTransmitting(true)
        if (!enabled) {
            backend.releaseFloor(session, channel.id)
            updateNotification("Ses bağlantısı hazır değil")
            return
        }

        transmitting = true
        updateNotification("YAYINDA • Ses karşıya gidiyor")

        leaseJob?.cancel()
        leaseJob = scope.launch {
            while (isActive && transmitting) {
                delay(8_000)
                val renewed = backend.acquireFloor(session, channel.id, 15)
                if (!renewed) {
                    ptt.setTransmitting(false)
                    transmitting = false
                    updateNotification("Yayın kesildi • Kanal kilidi yenilenemedi")
                    break
                }
            }
        }
    }

    private suspend fun endTransmit() {
        transmitting = false
        leaseJob?.cancel()
        leaseJob = null

        ptt.setTransmitting(false)

        val session = sessions.load()
        if (session != null) {
            backend.releaseFloor(session, store.loadActiveChannel().id)
        }

        updateNotification("Kanal dinlemede • Bas-konuş hazır")
    }

    private suspend fun stopRadio() {
        if (transmitting) endTransmit()
        started = false
        store.setRadioEnabled(false)
        ptt.disconnect()
        audioRoute.deactivate()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(text: String): Notification {
        val toggleIntent = Intent(this, PttForegroundService::class.java).apply {
            action = ACTION_TOGGLE_PTT
        }
        val stopIntent = Intent(this, PttForegroundService::class.java).apply {
            action = ACTION_STOP
        }

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("MELEHAT TELSİZ açık")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(
                android.R.drawable.ic_btn_speak_now,
                if (transmitting) "Yayını Kes" else "Bas-Konuş",
                PendingIntent.getService(this, 201, toggleIntent, flags)
            )
            .addAction(
                android.R.drawable.ic_delete,
                "Telsizi Kapat",
                PendingIntent.getService(this, 202, stopIntent, flags)
            )
            .build()
    }

    private fun startAsForeground(text: String) {
        val notification = buildNotification(text)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(
            NOTIFICATION_ID,
            buildNotification(text)
        )
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "MELEHAT TELSİZ",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Telsiz arka plan servisi ve PTT kontrolleri"
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
            )
        }
    }

    override fun onDestroy() {
        leaseJob?.cancel()
        networkMonitor.stop()
        mediaPtt.release()
        audioRoute.deactivate()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.saomi.telsiz.START"
        const val ACTION_STOP = "com.saomi.telsiz.STOP"
        const val ACTION_PTT_DOWN = "com.saomi.telsiz.PTT_DOWN"
        const val ACTION_PTT_UP = "com.saomi.telsiz.PTT_UP"
        const val ACTION_TOGGLE_PTT = "com.saomi.telsiz.TOGGLE_PTT"
        private const val CHANNEL_ID = "saomi_ptt"
        private const val NOTIFICATION_ID = 101
    }
}
