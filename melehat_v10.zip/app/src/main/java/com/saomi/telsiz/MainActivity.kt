package com.saomi.telsiz

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.core.content.ContextCompat
import com.saomi.telsiz.auth.SupabaseAuthClient
import com.saomi.telsiz.data.LocalStore
import com.saomi.telsiz.data.SessionStore
import com.saomi.telsiz.service.PttForegroundService
import com.saomi.telsiz.ui.AppRoot

class MainActivity : ComponentActivity() {

    private var volumePttDown = false
    private var authCallbackNonce = 0

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestRequiredPermissions()
        handleAuthIntent(intent)

        if (LocalStore(this).isRadioEnabled()) {
            sendServiceAction(PttForegroundService.ACTION_START)
        }

        render()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAuthIntent(intent)
        authCallbackNonce++
        render()
    }

    private fun render() {
        val nonce = authCallbackNonce
        setContent {
            MaterialTheme {
                AppRoot(
                    authCallbackNonce = nonce,
                    onRadioToggle = { enabled ->
                        sendServiceAction(
                            if (enabled) PttForegroundService.ACTION_START
                            else PttForegroundService.ACTION_STOP
                        )
                    },
                    onPtt = { down ->
                        sendServiceAction(
                            if (down) PttForegroundService.ACTION_PTT_DOWN
                            else PttForegroundService.ACTION_PTT_UP
                        )
                    }
                )
            }
        }
    }

    private fun handleAuthIntent(intent: Intent?) {
        val uri: Uri = intent?.data ?: return
        if (uri.scheme != "melehat" || uri.host != "auth-callback") return

        val store = SessionStore(this)
        val auth = SupabaseAuthClient()
        auth.sessionFromMagicLink(uri, store.pendingPhone(), store.pendingEmail())
            .onSuccess {
                store.save(it)
                store.clearPending()
            }
    }

    private fun requestRequiredPermissions() {
        val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (android.os.Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        if (android.os.Build.VERSION.SDK_INT >= 31) list += Manifest.permission.BLUETOOTH_CONNECT
        if (list.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            permissions.launch(list.toTypedArray())
        }
    }

    private fun sendServiceAction(action: String) {
        val i = Intent(this, PttForegroundService::class.java).apply { this.action = action }
        ContextCompat.startForegroundService(this, i)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP && !volumePttDown) {
            volumePttDown = true
            sendServiceAction(PttForegroundService.ACTION_PTT_DOWN)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP && volumePttDown) {
            volumePttDown = false
            sendServiceAction(PttForegroundService.ACTION_PTT_UP)
            return true
        }
        return super.onKeyUp(keyCode, event)
    }
}
