package com.saomi.telsiz.model

data class ChannelInfo(
    val id: String,
    val name: String,
    val memberCount: Int = 1
)
