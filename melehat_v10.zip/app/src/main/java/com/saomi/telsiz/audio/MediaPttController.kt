package com.saomi.telsiz.audio

import android.content.Context
import android.content.Intent
import android.view.KeyEvent
import androidx.media.session.MediaButtonReceiver
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import com.saomi.telsiz.service.PttForegroundService

class MediaPttController(
    private val context: Context,
    private val onTogglePtt: () -> Unit
) {
    private val session = MediaSessionCompat(context, "SaomiTelsizPTT").apply {
        setFlags(
            MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS
        )

        setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(
                    PlaybackStateCompat.ACTION_PLAY or
                        PlaybackStateCompat.ACTION_PAUSE or
                        PlaybackStateCompat.ACTION_PLAY_PAUSE
                )
                .setState(
                    PlaybackStateCompat.STATE_PAUSED,
                    0L,
                    1f
                )
                .build()
        )

        setCallback(object : MediaSessionCompat.Callback() {
            override fun onPlay() = onTogglePtt()
            override fun onPause() = onTogglePtt()

            override fun onMediaButtonEvent(mediaButtonEvent: Intent): Boolean {
                val event = mediaButtonEvent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)
                if (event?.action == KeyEvent.ACTION_DOWN) {
                    when (event.keyCode) {
                        KeyEvent.KEYCODE_HEADSETHOOK,
                        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                        KeyEvent.KEYCODE_MEDIA_PLAY,
                        KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                            onTogglePtt()
                            return true
                        }
                    }
                }
                return super.onMediaButtonEvent(mediaButtonEvent)
            }
        })

        isActive = true
    }

    fun release() {
        session.isActive = false
        session.release()
    }
}
