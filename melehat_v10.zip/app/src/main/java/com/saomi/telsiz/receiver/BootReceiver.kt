package com.saomi.telsiz.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.saomi.telsiz.data.LocalStore
import com.saomi.telsiz.service.PttForegroundService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!LocalStore(context).isRadioEnabled()) return

        val service = Intent(context, PttForegroundService::class.java).apply {
            action = PttForegroundService.ACTION_START
        }
        ContextCompat.startForegroundService(context, service)
    }
}
