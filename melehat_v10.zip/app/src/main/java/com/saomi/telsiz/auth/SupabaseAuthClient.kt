package com.saomi.telsiz.auth

import android.net.Uri
import android.util.Base64
import com.saomi.telsiz.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder

class SupabaseAuthClient {
    private val http = OkHttpClient()
    private val json = "application/json; charset=utf-8".toMediaType()

    private fun base() = BuildConfig.SUPABASE_URL.trimEnd('/')
    private fun key() = BuildConfig.SUPABASE_PUBLISHABLE_KEY

    fun isConfigured(): Boolean = base().isNotBlank() && key().isNotBlank()

    suspend fun sendMagicLink(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext Result.failure(
            IllegalStateException("Supabase bağlantısı henüz yapılandırılmadı.")
        )

        val redirect = URLEncoder.encode("melehat://auth-callback", "UTF-8")
        val body = JSONObject()
            .put("email", email.trim().lowercase())
            .put("create_user", true)
            .toString()
            .toRequestBody(json)

        val request = Request.Builder()
            .url("${base()}/auth/v1/otp?redirect_to=$redirect")
            .addHeader("apikey", key())
            .addHeader("Authorization", "Bearer ${key()}")
            .post(body)
            .build()

        runCatching {
            http.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    error("Onay bağlantısı gönderilemedi: ${response.code} ${raw.take(160)}")
                }
            }
        }
    }

    fun sessionFromMagicLink(uri: Uri, phone: String, fallbackEmail: String): Result<AuthSession> = runCatching {
        if (uri.scheme != "melehat" || uri.host != "auth-callback") {
            error("Geçersiz MELEHAT giriş bağlantısı.")
        }

        val values = linkedMapOf<String, String>()
        val raw = listOfNotNull(uri.query, uri.fragment).joinToString("&")
        raw.split("&").forEach { pair ->
            val i = pair.indexOf('=')
            if (i > 0) {
                val k = Uri.decode(pair.substring(0, i))
                val v = Uri.decode(pair.substring(i + 1))
                values[k] = v
            }
        }

        values["error_description"]?.takeIf { it.isNotBlank() }?.let { error(it) }
        val access = values["access_token"].orEmpty()
        val refresh = values["refresh_token"].orEmpty()
        if (access.isBlank()) error("Onay bağlantısında oturum bilgisi bulunamadı.")

        val payloadPart = access.split('.').getOrNull(1).orEmpty()
        if (payloadPart.isBlank()) error("Oturum anahtarı okunamadı.")
        val padded = payloadPart + "=".repeat((4 - payloadPart.length % 4) % 4)
        val payload = String(Base64.decode(padded, Base64.URL_SAFE or Base64.NO_WRAP), Charsets.UTF_8)
        val jwt = JSONObject(payload)
        val userId = jwt.optString("sub")
        val email = jwt.optString("email").ifBlank { fallbackEmail.trim().lowercase() }
        if (userId.isBlank()) error("Kullanıcı kimliği alınamadı.")

        AuthSession(
            accessToken = access,
            refreshToken = refresh,
            userId = userId,
            phone = phone.trim(),
            email = email
        )
    }
}
