package com.saomi.telsiz.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.saomi.telsiz.auth.SupabaseAuthClient
import com.saomi.telsiz.data.BackendApi
import com.saomi.telsiz.data.LocalStore
import com.saomi.telsiz.data.SessionStore
import com.saomi.telsiz.model.ChannelInfo
import com.saomi.telsiz.model.UserProfile
import kotlinx.coroutines.launch

@Composable
fun AppRoot(
    authCallbackNonce: Int,
    onRadioToggle: (Boolean) -> Unit,
    onPtt: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val localStore = remember { LocalStore(context) }
    val sessionStore = remember { SessionStore(context) }
    val auth = remember { SupabaseAuthClient() }
    val backend = remember { BackendApi(context) }

    var session by remember(authCallbackNonce) { mutableStateOf(sessionStore.load()) }
    var loginPhone by remember { mutableStateOf(session?.phone.orEmpty()) }
    var loginEmail by remember { mutableStateOf(session?.email.orEmpty()) }
    var linkSent by remember { mutableStateOf(false) }
    var authMessage by remember { mutableStateOf("") }

    var profile by remember { mutableStateOf(localStore.loadProfile()) }
    var activeChannel by remember { mutableStateOf(localStore.loadActiveChannel()) }
    var radioOn by remember { mutableStateOf(localStore.isRadioEnabled()) }
    var transmitting by remember { mutableStateOf(false) }
    var fullName by remember { mutableStateOf(profile.fullName) }
    var photoUri by remember { mutableStateOf(profile.photoUri) }
    var channelText by remember { mutableStateOf(activeChannel.name) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { photoUri = it.toString() }
    }

    LaunchedEffect(session?.userId, authCallbackNonce) {
        val current = session ?: return@LaunchedEffect
        backend.fetchMyProfile(current)
            .onSuccess { existing ->
                if (existing != null) {
                    if (existing.phone.isNotBlank() && normalizePhone(existing.phone) != normalizePhone(current.phone)) {
                        sessionStore.clear()
                        localStore.clearProfile()
                        session = null
                        profile = UserProfile()
                        authMessage = "Bu e-posta başka bir telefon numarasıyla kayıtlı."
                    } else {
                        localStore.saveProfile(existing)
                        profile = existing
                        fullName = existing.fullName
                        photoUri = existing.photoUri
                    }
                } else {
                    val fresh = UserProfile(
                        phone = current.phone,
                        email = current.email,
                        fullName = "",
                        photoUri = ""
                    )
                    localStore.saveProfile(fresh)
                    profile = fresh
                }
            }
            .onFailure { authMessage = it.message.orEmpty() }
    }

    val infinite = rememberInfiniteTransition(label = "rings")
    val pulse by infinite.animateFloat(
        initialValue = 0.80f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulse"
    )

    Scaffold(
        topBar = {
            Surface(shadowElevation = 2.dp) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("MELEHAT TELSİZ", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("v0.10 • E-posta bağlantısı • Profil • Kanal • PTT", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (session == null) {
                Text("Hesaba giriş", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Telefon numaranızı ve e-postanızı girin. E-postaya gelen güvenli giriş bağlantısına dokunun.")

                OutlinedTextField(
                    value = loginPhone,
                    onValueChange = { loginPhone = it },
                    label = { Text("Telefon (+90...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = loginEmail,
                    onValueChange = { loginEmail = it.trim() },
                    label = { Text("E-posta") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = {
                        scope.launch {
                            authMessage = "Gönderiliyor…"
                            sessionStore.savePending(loginPhone, loginEmail)
                            auth.sendMagicLink(loginEmail)
                                .onSuccess {
                                    linkSent = true
                                    authMessage = "Giriş bağlantısı e-postanıza gönderildi. Maildeki bağlantıya dokunun; MELEHAT TELSİZ otomatik açılır."
                                }
                                .onFailure { authMessage = it.message.orEmpty() }
                        }
                    },
                    enabled = loginPhone.isNotBlank() && loginEmail.contains("@"),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (linkSent) "Bağlantıyı Tekrar Gönder" else "E-postaya Giriş Bağlantısı Gönder")
                }

                if (linkSent) {
                    Text(
                        "Bağlantıyı aynı telefondan açın. Doğrulama tamamlanınca uygulama doğrudan hesabınıza döner.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                if (authMessage.isNotBlank()) {
                    Text(authMessage, style = MaterialTheme.typography.bodySmall)
                }
                return@Column
            }

            if (!profile.isComplete || profile.email != session!!.email || normalizePhone(profile.phone) != normalizePhone(session!!.phone)) {
                Text("Profilini tamamla", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Ad-soyad ve profil fotoğrafı zorunludur.")

                OutlinedTextField(
                    value = session!!.phone,
                    onValueChange = {},
                    label = { Text("Telefon") },
                    enabled = false,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = session!!.email,
                    onValueChange = {},
                    label = { Text("Doğrulanmış e-posta") },
                    enabled = false,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Ad Soyad") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (photoUri.isBlank()) "Profil Fotoğrafı Seç" else "Fotoğrafı Değiştir")
                }

                photoUri.takeIf(String::isNotBlank)?.let { uriString ->
                    val bmp = remember(uriString) {
                        runCatching {
                            context.contentResolver.openInputStream(Uri.parse(uriString))?.use(BitmapFactory::decodeStream)
                        }.getOrNull()
                    }
                    bmp?.let {
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = null,
                            modifier = Modifier.size(96.dp),
                            contentScale = ContentScale.Crop
                        )
                    }
                }

                Button(
                    onClick = {
                        val p = UserProfile(
                            phone = session!!.phone,
                            email = session!!.email,
                            fullName = fullName.trim(),
                            photoUri = photoUri
                        )
                        scope.launch {
                            backend.uploadProfilePhoto(session!!, p.photoUri)
                                .onSuccess { publicUrl ->
                                    val cloudProfile = p.copy(photoUri = publicUrl)
                                    backend.upsertProfile(session!!, cloudProfile)
                                        .onSuccess {
                                            localStore.saveProfile(cloudProfile)
                                            profile = cloudProfile
                                            authMessage = "Profil kaydedildi."
                                        }
                                        .onFailure { authMessage = it.message.orEmpty() }
                                }
                                .onFailure { authMessage = it.message.orEmpty() }
                        }
                    },
                    enabled = fullName.isNotBlank() && photoUri.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Profili Kaydet") }

                if (authMessage.isNotBlank()) Text(authMessage, style = MaterialTheme.typography.bodySmall)
                return@Column
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(profile.fullName, fontWeight = FontWeight.Bold)
                    Text(profile.phone, style = MaterialTheme.typography.bodySmall)
                    Text(profile.email, style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = {
                    if (radioOn) {
                        radioOn = false
                        localStore.setRadioEnabled(false)
                        onRadioToggle(false)
                    }
                    sessionStore.clear()
                    localStore.clearProfile()
                    session = null
                    profile = UserProfile()
                    loginPhone = ""
                    loginEmail = ""
                    linkSent = false
                    authMessage = ""
                }) { Text("Çıkış") }
            }

            OutlinedTextField(
                value = channelText,
                onValueChange = { channelText = it.uppercase() },
                label = { Text("Kanal") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Button(
                onClick = {
                    val c = ChannelInfo(
                        id = slug(channelText.ifBlank { "KANAL 1" }),
                        name = channelText.ifBlank { "KANAL 1" }
                    )
                    activeChannel = c
                    localStore.saveActiveChannel(c)
                    scope.launch { backend.joinChannel(session!!, c) }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Kanala Gir") }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Telsiz durumu", fontWeight = FontWeight.SemiBold)
                    Text(if (radioOn) "AÇIK • ${activeChannel.name}" else "KAPALI")
                }
                Switch(
                    checked = radioOn,
                    onCheckedChange = {
                        radioOn = it
                        localStore.setRadioEnabled(it)
                        onRadioToggle(it)
                    }
                )
            }

            Box(Modifier.size(270.dp), contentAlignment = Alignment.Center) {
                if (radioOn && !transmitting) {
                    Canvas(Modifier.fillMaxSize()) {
                        val c = Offset(size.width / 2, size.height / 2)
                        drawCircle(Color(0x5534C759), size.minDimension * 0.34f * pulse, c)
                        drawCircle(Color(0x3334C759), size.minDimension * 0.44f * pulse, c)
                    }
                }
                Surface(
                    modifier = Modifier
                        .size(185.dp)
                        .pointerInput(radioOn) {
                            detectTapGestures(onPress = {
                                if (!radioOn) return@detectTapGestures
                                transmitting = true
                                onPtt(true)
                                tryAwaitRelease()
                                transmitting = false
                                onPtt(false)
                            })
                        },
                    shape = CircleShape,
                    color = when {
                        !radioOn -> Color(0xFFE0E0E0)
                        transmitting -> Color(0xFFD32F2F)
                        else -> Color(0xFF34C759)
                    },
                    shadowElevation = 8.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                when {
                                    !radioOn -> "TELSİZ KAPALI"
                                    transmitting -> "SES GİDİYOR"
                                    else -> "BAS KONUŞ"
                                },
                                fontWeight = FontWeight.Bold,
                                color = if (radioOn) Color.White else Color.DarkGray
                            )
                            if (radioOn) {
                                Text(
                                    if (transmitting) "Kırmızı = Yayın" else "Yeşil = Hazır",
                                    color = Color.White,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }

            Surface(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFF2F2F7)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("MELEHAT TELSİZ v0.10", fontWeight = FontWeight.Bold)
                    Text("• SMS ve Twilio yok")
                    Text("• E-posta güvenli giriş bağlantısı")
                    Text("• Aynı cihazda oturum hatırlanır")
                    Text("• Yeni telefonda aynı e-postaya yeni bağlantı gönderilir")
                    Text("• Kayıtlı telefon numarası eşleşmelidir")
                    Text("• Profil fotoğrafı zorunlu")
                }
            }
        }
    }
}

private fun normalizePhone(value: String): String =
    value.filter(Char::isDigit).removePrefix("0")

private fun slug(value: String): String =
    value.lowercase()
        .replace("ç", "c").replace("ğ", "g").replace("ı", "i")
        .replace("ö", "o").replace("ş", "s").replace("ü", "u")
        .replace(Regex("[^a-z0-9]+"), "-")
        .trim('-')
        .ifBlank { "kanal-1" }
