package com.saomi.telsiz.data

import android.content.Context
import com.saomi.telsiz.auth.AuthSession

class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("melehat_telsiz_auth", Context.MODE_PRIVATE)

    fun save(session: AuthSession) {
        prefs.edit()
            .putString("access_token", session.accessToken)
            .putString("refresh_token", session.refreshToken)
            .putString("user_id", session.userId)
            .putString("phone", session.phone)
            .putString("email", session.email)
            .apply()
    }

    fun load(): AuthSession? {
        val access = prefs.getString("access_token", "").orEmpty()
        val userId = prefs.getString("user_id", "").orEmpty()
        if (access.isBlank() || userId.isBlank()) return null
        return AuthSession(
            accessToken = access,
            refreshToken = prefs.getString("refresh_token", "").orEmpty(),
            userId = userId,
            phone = prefs.getString("phone", "").orEmpty(),
            email = prefs.getString("email", "").orEmpty()
        )
    }

    fun savePending(phone: String, email: String) {
        prefs.edit()
            .putString("pending_phone", phone.trim())
            .putString("pending_email", email.trim().lowercase())
            .apply()
    }

    fun pendingPhone(): String = prefs.getString("pending_phone", "").orEmpty()
    fun pendingEmail(): String = prefs.getString("pending_email", "").orEmpty()

    fun clearPending() {
        prefs.edit().remove("pending_phone").remove("pending_email").apply()
    }

    fun clear() = prefs.edit().clear().apply()
}
