package com.saomi.telsiz.voice

import android.content.Context
import com.saomi.telsiz.model.ChannelInfo
import com.saomi.telsiz.model.UserProfile
import io.livekit.android.LiveKit
import io.livekit.android.room.Room

class LiveKitPttClient(private val context: Context) {

    private var room: Room? = null
    private var connected = false
    private val tokenClient = TokenClient(context)

    suspend fun connect(profile: UserProfile, channel: ChannelInfo): Boolean {
        if (connected) return true
        if (!profile.isComplete) return false

        val identity = profile.phone.filter { it.isDigit() }.ifBlank { profile.fullName }
        val credentials = tokenClient.fetch(
            roomName = channel.id,
            participantName = profile.fullName,
            participantIdentity = identity
        ) ?: return false

        val r = LiveKit.create(context)
        return runCatching {
            r.connect(credentials.serverUrl, credentials.participantToken)
            r.localParticipant.setMicrophoneEnabled(false)
            room = r
            connected = true
            true
        }.getOrElse {
            runCatching { r.disconnect() }
            false
        }
    }

    suspend fun setTransmitting(enabled: Boolean): Boolean {
        val r = room ?: return false
        return runCatching {
            r.localParticipant.setMicrophoneEnabled(enabled)
            true
        }.getOrDefault(false)
    }

    suspend fun disconnect() {
        runCatching { room?.localParticipant?.setMicrophoneEnabled(false) }
        runCatching { room?.disconnect() }
        room = null
        connected = false
    }

    fun isConnected(): Boolean = connected
}
